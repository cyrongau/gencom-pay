---
name: Generex Identity
colors:
  surface: '#0e141b'
  surface-dim: '#0e141b'
  surface-bright: '#343a41'
  surface-container-lowest: '#090f15'
  surface-container-low: '#161c23'
  surface-container: '#1a2027'
  surface-container-high: '#252a32'
  surface-container-highest: '#2f353d'
  on-surface: '#dee3ed'
  on-surface-variant: '#c6c6cd'
  inverse-surface: '#dee3ed'
  inverse-on-surface: '#2b3138'
  outline: '#909097'
  outline-variant: '#45464d'
  surface-tint: '#bfc6e0'
  primary: '#bfc6e0'
  on-primary: '#293044'
  primary-container: '#0b1225'
  on-primary-container: '#777d95'
  inverse-primary: '#575e74'
  secondary: '#44e185'
  on-secondary: '#00391b'
  secondary-container: '#04c16a'
  on-secondary-container: '#004823'
  tertiary: '#b9c3ff'
  on-tertiary: '#002388'
  tertiary-container: '#000c41'
  on-tertiary-container: '#5673f3'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#dbe1fd'
  primary-fixed-dim: '#bfc6e0'
  on-primary-fixed: '#141b2e'
  on-primary-fixed-variant: '#40465c'
  secondary-fixed: '#66fe9f'
  secondary-fixed-dim: '#44e185'
  on-secondary-fixed: '#00210d'
  on-secondary-fixed-variant: '#00522a'
  tertiary-fixed: '#dde1ff'
  tertiary-fixed-dim: '#b9c3ff'
  on-tertiary-fixed: '#001356'
  on-tertiary-fixed-variant: '#0b36b9'
  background: '#0e141b'
  on-background: '#dee3ed'
  surface-variant: '#2f353d'
typography:
  display-xl:
    fontFamily: Inter
    fontSize: 60px
    fontWeight: '700'
    lineHeight: 72px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Inter
    fontSize: 36px
    fontWeight: '600'
    lineHeight: 44px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-sm:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-xs:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  unit: 8px
  container-max: 1280px
  gutter: 24px
  margin: 32px
  stack-xs: 4px
  stack-sm: 8px
  stack-md: 16px
  stack-lg: 24px
  stack-xl: 48px
---

## Brand & Style

The design system is engineered to project an image of institutional stability merged with cutting-edge technological agility. It targets high-stakes fintech environments where clarity and precision are paramount. The visual style follows a **Modern Corporate** movement with **Glassmorphic** accents to suggest depth and data transparency.

The interface should feel architectural and intentional. We utilize heavy whitespace to reduce cognitive load while employing vibrant, high-tech gradients to draw the eye toward growth metrics and key conversion points. The emotional response is one of absolute reliability, sophistication, and forward-looking optimism.

## Colors

This design system utilizes a sophisticated dark-mode default to emphasize the "Midnight Navy" foundation. **Midnight Navy** serves as the primary canvas, providing a sense of grounded authority. **Generex Green** and **Generex Blue** act as functional accents—Green for success states and growth indicators, Blue for interactive technological components.

**Deep Teal** is reserved for container surfaces to provide subtle contrast against the navy background. **Gold** is a high-priority accent color, used sparingly for VIP status or critical "Commit" actions. Gradients should be used as background fills for data visualizations or primary call-to-action buttons to imply kinetic energy and movement.

## Typography

The typography system is built exclusively on **Inter**, a typeface designed for maximum legibility in data-heavy interfaces. The hierarchy is strictly enforced through weight and letter-spacing adjustments rather than excessive size variations.

- **Display & Headlines:** Use tighter letter spacing and bold weights to create a high-impact, technical feel.
- **Body Text:** Standard weights with generous line heights to ensure readability in complex financial documents.
- **Labels:** Small caps or medium weights are used for metadata and micro-copy to distinguish them from primary content.

## Layout & Spacing

This design system employs a **12-column fixed grid** for desktop and a fluid single-column for mobile. The spacing logic is based on a **8px (Round Eight)** scale, ensuring all dimensions are multiples of 8 to maintain mathematical harmony and alignment.

Layouts should favor vertical stacking for data lists and a modular "bento-box" style for dashboards. Gutters are kept wide (24px) to ensure that even complex data sets have room to breathe, preventing the "cluttered" look common in legacy fintech apps.

## Elevation & Depth

Visual hierarchy is established through **Tonal Layering** supplemented by **Glassmorphism**. Instead of traditional black shadows, depth is created by shifting the background color:

1.  **Level 0 (Background):** Midnight Navy (#0B1225).
2.  **Level 1 (Cards):** Deep Teal (#0F3D3A) with a 1px inner stroke of 10% white to define the edge.
3.  **Level 2 (Modals/Popovers):** A semi-transparent blur (Backdrop-filter: blur(20px)) with a 15% Blue tint to simulate "Tech-Glass."

Shadows, when used, are "Ambient Shadows"—wide, extremely soft, and tinted with the primary blue color rather than neutral grey, suggesting a glow from the screen's digital elements.

## Shapes

The "Round Eight" philosophy dictates a consistent **8px (0.5rem)** radius for all primary containers and components. This creates a friendly yet professional appearance that feels modern without being overly "bubbly."

- **Buttons & Inputs:** Use the standard 8px radius.
- **Outer Containers (Large Cards):** May scale up to 16px (rounded-lg) to create a nested visual containment.
- **Icon Enclosures:** Small circular containers (pill-shaped) may be used for status pips and profile avatars to provide organic contrast against the geometric grid.

## Components

- **Buttons:** 
    - *Primary:* Signature Green-to-Blue gradient with white text. 
    - *Secondary:* Deep Teal background with a 1px Blue border.
    - *High-Value:* Solid Gold background with Midnight Navy text for maximum contrast.
- **Inputs:** Dark background (#060914) with an 8px radius. Active states feature a 2px Generex Blue border and a subtle outer glow.
- **Cards:** Use Deep Teal for the surface. In dashboards, cards should have a subtle 1px border (#ffffff1a) to separate data sections without heavy shadows.
- **Chips/Badges:** Small, pill-shaped elements with low-opacity background fills of their respective status color (e.g., Green fill at 15% opacity for "Growth" badges).
- **Data Visuals:** Charts should exclusively use the system's gradients. Line charts should utilize the Teal-to-Green gradient to emphasize positive trendlines.
- **Lists:** Clean rows with 1px Midnight Navy dividers. Hover states should trigger a subtle shift to the Deep Teal surface color.