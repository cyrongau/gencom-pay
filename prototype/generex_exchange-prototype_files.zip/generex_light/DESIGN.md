---
name: Generex Light
colors:
  surface: '#f7fafd'
  surface-dim: '#d7dadd'
  surface-bright: '#f7fafd'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f1f4f7'
  surface-container: '#ebeef1'
  surface-container-high: '#e5e8eb'
  surface-container-highest: '#e0e3e6'
  on-surface: '#181c1e'
  on-surface-variant: '#444654'
  inverse-surface: '#2d3133'
  inverse-on-surface: '#eef1f4'
  outline: '#747685'
  outline-variant: '#c4c5d6'
  surface-tint: '#3252d1'
  primary: '#2d4dcd'
  on-primary: '#ffffff'
  primary-container: '#4a68e7'
  on-primary-container: '#fcf9ff'
  inverse-primary: '#b9c3ff'
  secondary: '#006d39'
  on-secondary: '#ffffff'
  secondary-container: '#63fb9c'
  on-secondary-container: '#00723c'
  tertiary: '#535a70'
  on-tertiary: '#ffffff'
  tertiary-container: '#6c728a'
  on-tertiary-container: '#fbf9ff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dde1ff'
  primary-fixed-dim: '#b9c3ff'
  on-primary-fixed: '#001356'
  on-primary-fixed-variant: '#0b36b9'
  secondary-fixed: '#66fe9f'
  secondary-fixed-dim: '#44e185'
  on-secondary-fixed: '#00210d'
  on-secondary-fixed-variant: '#00522a'
  tertiary-fixed: '#dbe1fd'
  tertiary-fixed-dim: '#bfc6e0'
  on-tertiary-fixed: '#141b2e'
  on-tertiary-fixed-variant: '#40465c'
  background: '#f7fafd'
  on-background: '#181c1e'
  surface-variant: '#e0e3e6'
typography:
  display:
    fontFamily: Inter
    fontSize: 48px
    fontWeight: '700'
    lineHeight: '1.1'
    letterSpacing: -0.02em
  h1:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '600'
    lineHeight: '1.2'
    letterSpacing: -0.01em
  h2:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: '1.3'
    letterSpacing: -0.01em
  h3:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: '1.4'
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.5'
  body-sm:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: '1.5'
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: '1'
    letterSpacing: 0.05em
  label-sm:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '500'
    lineHeight: '1'
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  unit: 8px
  container-max: 1280px
  gutter: 24px
  margin-page: 32px
  stack-xs: 4px
  stack-sm: 8px
  stack-md: 16px
  stack-lg: 24px
  stack-xl: 48px
---

## Brand & Style

The design system is engineered to project institutional stability while maintaining the agility of a modern fintech platform. The brand personality is "The Precise Navigator"—calm, expert, and transparent. The aesthetic combines **Minimalism** with **Modern Corporate** sensibilities, utilizing expansive whitespace and high-quality typography to ensure clarity in complex financial data environments.

The visual narrative focuses on "structural confidence." By grounding the interface in deep navy and soft sky tones, we create a high-trust atmosphere where growth and action are highlighted through vibrant, purposeful pops of green and blue. The experience should feel effortless, reducing the cognitive load of asset management through a light-filled, airy environment.

## Colors

The palette is divided into functional layers to drive user focus. 

- **Surface Layers:** Use #F3F6F9 for the base application background and #F0F5FF for secondary surface containers or sidebar regions to provide a subtle "cool sky" depth.
- **Typography & Structure:** #0B1225 (Midnight Navy) is the anchor, used for all primary text and structural borders to ensure WCAG AA accessibility and a sense of permanence.
- **Growth & Liquidity:** #16C66E (Generex Green) is reserved strictly for positive financial trends, success states, and liquidity indicators.
- **Action & Interaction:** #4A68E7 (Generex Blue) signals interactivity—links, focused states, and secondary buttons.
- **Primary Actions:** The signature green-to-blue gradient is used exclusively for high-intent primary actions (e.g., "Invest," "Submit," "Connect Wallet"), symbolizing the bridge between growth and technology.

## Typography

This design system utilizes **Inter** for its entire typographic scale. Inter provides a utilitarian, systematic feel that is essential for financial legibility. 

Headlines utilize tighter tracking and heavier weights to provide a bold contrast against the light surfaces. Body text remains at a standard weight with generous line height to ensure readability in data-dense tables and descriptions. Labels use a slightly increased letter-spacing and uppercase styling for "meta" information (like table headers or category tags) to distinguish them from interactive content.

## Layout & Spacing

This design system employs a **12-column fixed grid** for desktop environments, centered with a maximum width of 1280px. The internal spacing rhythm is based on an **8px base unit**, ensuring mathematical harmony between all elements.

- **Gutters:** Standardized at 24px to provide clear separation between data modules.
- **Margins:** Page-level margins are 32px to allow the interface to breathe against the browser edge.
- **Modular Padding:** Components (like cards) should use a consistent 24px internal padding, while vertical stacking of sections should utilize 48px to clearly demarcate the transition from one functional area to another.

## Elevation & Depth

To maintain a "clean" fintech aesthetic, this design system avoids heavy shadows. Instead, it relies on **Tonal Layers** and **Low-Contrast Outlines**.

- **Level 0 (Background):** #F3F6F9 (Neutral Grey).
- **Level 1 (Cards/Modules):** Pure White (#FFFFFF) surfaces with a subtle 1px border using #0B1225 at 8% opacity. No shadow.
- **Level 2 (Popovers/Modals):** Pure White (#FFFFFF) surfaces with a soft, ambient shadow: `0px 12px 32px rgba(11, 18, 37, 0.08)`. This creates a sense of hovering without breaking the clean aesthetic.
- **Depth Cues:** Interaction is indicated by a subtle shift to #F0F5FF (Cool Sky) on hover for non-primary elements.

## Shapes

The shape language is defined as **Rounded**, striking a balance between the rigidity of finance and the friendliness of modern SaaS.

- **Standard Radius (8px):** Applied to buttons, input fields, and small modules.
- **Large Radius (16px):** Applied to main dashboard cards and container wrappers.
- **Extra Large Radius (24px):** Applied to promotional banners or unique decorative elements.
- **Pill (Full Round):** Used exclusively for status chips (e.g., "Active", "Pending") and small interactive tags.

## Components

- **Buttons:** Primary buttons use the green-to-blue gradient with white text. Secondary buttons use a #0B1225 outline with 10% opacity. Interaction states (hover) for primary buttons should subtly increase the gradient saturation.
- **Input Fields:** Use a white background, an 8px corner radius, and a 1px border (#0B1225 at 12% opacity). On focus, the border shifts to Generex Blue (#4A68E7) with a 2px outer glow.
- **Cards:** White containers with 16px corner radius. Headlines inside cards should be Midnight Navy (#0B1225).
- **Chips:** Status chips use a 10% opacity background of their respective state color (e.g., 10% Generex Green background with 100% Generex Green text).
- **Lists:** Table rows and lists should use a subtle #F3F6F9 divider. Hover states on list items should utilize the Cool Sky (#F0F5FF) tint.
- **Financial Charts:** Use Generex Green (#16C66E) for growth lines and Generex Blue (#4A68E7) for secondary data points. Area charts should use a vertical gradient fading from 20% opacity to 0%.